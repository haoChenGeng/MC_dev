import React from 'react';
import assign from 'object-assign';

class ListLi extends React.Component{
  constructor(props) {
    super(props);
  }
  render() {
    console.log(this.props);
    return (
      <li className="list-li">
        <div className="list-li-left">
          <p><span style={this.props.status == '借款申请中' ? assign({},styles.success) : assign({},styles.fail)}></span>{this.props.amount || 1}</p>
          <p>{this.props.date || 2}</p>
        </div>
        <div className="list-li-right">
          {this.props.statusStr}
        </div>
      </li>
    )
  }
}

var styles = {
  success: {
    backgroundColor: '#ff0000'
  },
  fail: {
    backgroundColor: '#506FEE'
  }
}

export default ListLi;